// === DOM references ===
const companySelect = document.getElementById("company-select");
const deviceGrid = document.getElementById("device-grid");
const emptyState = document.getElementById("empty-state");
const errorState = document.getElementById("error-state");
const notificationBanner = document.getElementById("notification-banner");
const lastUpdatedEl = document.getElementById("last-updated");
const refreshIndicator = document.getElementById("refresh-indicator");
const searchInput = document.getElementById("search-input");
const filterButtons = document.querySelectorAll(".filter-btn");

// Modal elements
const deviceModal = document.getElementById("device-modal");
const modalCloseBtn = document.getElementById("modal-close");
const modalDeviceName = document.getElementById("modal-device-name");
const modalCompanyName = document.getElementById("modal-company-name");
const modalStatus = document.getElementById("modal-status");
const modalLastSeen = document.getElementById("modal-last-seen");
const chartCanvas = document.getElementById("device-chart");

let currentDevices = [];
let previousStatusMap = {};
let currentFilter = "all";
let refreshIntervalId = null;
let socket = null;
let deviceChart = null; // Chart.js instance

// === Utility functions ===
function formatDateTime(isoString) {
  if (!isoString) return "Never";
  const d = new Date(isoString);
  return d.toLocaleString();
}

function setLastUpdated() {
  lastUpdatedEl.textContent = new Date().toLocaleTimeString();
}

function showNotification(devices) {
  if (!devices.length) return;
  const names = devices.map((d) => d.name).join(", ");
  notificationBanner.textContent = `New devices came online: ${names}`;
  notificationBanner.classList.remove("hidden");
  setTimeout(() => {
    notificationBanner.classList.add("hidden");
  }, 5000);
}

// === Fetch helpers ===
async function fetchCompanies() {
  const res = await fetch("/api/companies");
  if (!res.ok) {
    throw new Error("Failed to fetch companies");
  }
  return res.json();
}

async function fetchDevices(companyId) {
  if (!companyId) return [];
  try {
    refreshIndicator.classList.remove("hidden");
    const res = await fetch(`/api/companies/${companyId}/devices`);
    if (!res.ok) throw new Error("Failed to fetch devices");
    const data = await res.json();
    refreshIndicator.classList.add("hidden");
    return data;
  } catch (err) {
    refreshIndicator.classList.add("hidden");
    console.error("fetchDevices error:", err);
    throw err;
  }
}

async function fetchDeviceHistory(deviceId, limit = 50) {
  const res = await fetch(`/api/companies/device/${deviceId}/history?limit=${limit}`);
  if (!res.ok) {
    throw new Error("Failed to fetch history");
  }
  return res.json();
}

// === Rendering ===
function renderCompanies(companies) {
  companySelect.innerHTML = '<option value="">Select a company...</option>';
  companies.forEach((c) => {
    const opt = document.createElement("option");
    opt.value = c.id;
    opt.textContent = c.name;
    companySelect.appendChild(opt);
  });
}

function applyFilters(devices) {
  const term = searchInput.value.trim().toLowerCase();
  return devices.filter((d) => {
    const matchesFilter =
      currentFilter === "all" ? true : d.status === currentFilter;
    const matchesSearch =
      !term || d.name.toLowerCase().includes(term);
    return matchesFilter && matchesSearch;
  });
}

function renderDevices(devices) {
  deviceGrid.innerHTML = "";
  const filtered = applyFilters(devices);

  if (!filtered.length) {
    deviceGrid.innerHTML =
      "<p style='color:#9ca3af;font-size:0.9rem;'>No devices match your filters.</p>";
    return;
  }

  filtered.forEach((d) => {
    const card = document.createElement("div");
    card.className = "device-card";
    card.dataset.deviceId = d.id;

    const statusClass =
      d.status === "online" ? "status-online" : "status-offline";
    const statusLabel = d.status === "online" ? "Online" : "Offline";
    const lastValueDisplay =
      d.last_value !== undefined && d.last_value !== null
        ? d.last_value
        : "--";

    card.innerHTML = `
      <div class="device-name">${d.name}</div>
      <div class="device-meta">
        <span class="status-pill ${statusClass}">
          <span class="status-dot"></span>
          ${statusLabel}
        </span>
        <span class="company-name">${d.company_name}</span>
      </div>
      <div class="last-seen">
        Last seen: ${formatDateTime(d.last_seen)}
      </div>
      <div class="last-seen">
        Value: ${lastValueDisplay}
      </div>
    `;

    card.addEventListener("click", () => openDeviceModal(d));
    deviceGrid.appendChild(card);
  });
}

// === Modal + Chart ===
async function openDeviceModal(device) {
  modalDeviceName.textContent = device.name;
  modalCompanyName.textContent = device.company_name;
  modalStatus.textContent = device.status.toUpperCase();
  modalStatus.style.color =
    device.status === "online" ? "#22c55e" : "#ef4444";
  modalLastSeen.textContent = formatDateTime(device.last_seen);

  deviceModal.classList.remove("hidden");

  try {
    const history = await fetchDeviceHistory(device.id);
    drawDeviceChart(history);
  } catch (err) {
    console.error("History load error:", err);
  }
}

function closeDeviceModal() {
  deviceModal.classList.add("hidden");
}

function drawDeviceChart(history) {
  if (!chartCanvas) return;
  const ctx = chartCanvas.getContext("2d");

  const labels = history.map((h) =>
    h.reading_time ? new Date(h.reading_time).toLocaleTimeString() : ""
  );
  const values = history.map((h) => h.value ?? null);

  if (deviceChart) {
    deviceChart.destroy();
  }

  deviceChart = new Chart(ctx, {
    type: "line",
    data: {
      labels,
      datasets: [
        {
          label: "Sensor value",
          data: values,
          borderWidth: 2,
          tension: 0.3,
          pointRadius: 0
        }
      ]
    },
    options: {
      responsive: true,
      scales: {
        x: {
          ticks: {
            maxTicksLimit: 6
          }
        }
      }
    }
  });
}

// === Live updates (WebSocket) ===
function initSocket() {
  socket = io();

  socket.on("connect", () => {
    console.log("Socket connected");
    const companyId = companySelect.value;
    if (companyId) {
      socket.emit("join_company", { company_id: parseInt(companyId) });
      socket.emit("start_stream", {});
    }
  });

  socket.on("device_reading", (payload) => {
    console.log("Live reading: ", payload);
    handleLiveReading(payload);
  });
}

function handleLiveReading(payload) {
  const {
    device_id,
    device_name,
    company_id,
    company_name,
    value,
    reading_time,
    status
  } = payload;

  const selectedCompanyId = parseInt(companySelect.value || "0");
  if (!selectedCompanyId || selectedCompanyId !== company_id) {
    return;
  }

  let found = false;
  currentDevices = currentDevices.map((d) => {
    if (d.id === device_id) {
      found = true;
      previousStatusMap[d.id] = d.status;
      return {
        ...d,
        name: device_name,
        company_id,
        company_name,
        status,
        last_seen: reading_time,
        last_value: value
      };
    }
    return d;
  });

  if (!found) {
    currentDevices.push({
      id: device_id,
      name: device_name,
      company_id,
      company_name,
      status,
      last_seen: reading_time,
      last_value: value
    });
  }

  renderDevices(currentDevices);

  // Update chart if this device is currently open
  if (
    !deviceModal.classList.contains("hidden") &&
    modalDeviceName.textContent === device_name &&
    deviceChart
  ) {
    const t = new Date(reading_time).toLocaleTimeString();
    deviceChart.data.labels.push(t);
    deviceChart.data.datasets[0].data.push(value);
    if (deviceChart.data.labels.length > 50) {
      deviceChart.data.labels.shift();
      deviceChart.data.datasets[0].data.shift();
    }
    deviceChart.update();
  }
}

// === Load devices for selected company ===
async function loadDevicesForSelectedCompany(showNotifications = true) {
  const companyId = companySelect.value;

  if (!companyId) {
    deviceGrid.innerHTML = "";
    emptyState.classList.remove("hidden");
    errorState.classList.add("hidden");
    return;
  }

  try {
    errorState.classList.add("hidden");
    emptyState.classList.add("hidden");

    const devices = await fetchDevices(companyId);

    const newlyOnline = [];
    devices.forEach((d) => {
      const prev = previousStatusMap[d.id];
      if (prev === "offline" && d.status === "online") {
        newlyOnline.push(d);
      }
      previousStatusMap[d.id] = d.status;
    });

    currentDevices = devices;
    renderDevices(currentDevices);
    setLastUpdated();

    if (showNotifications && newlyOnline.length) {
      showNotification(newlyOnline);
    }
  } catch (err) {
    console.error("loadDevicesForSelectedCompany error:", err);
    errorState.classList.remove("hidden");
  }
}

// === Event listeners ===
companySelect.addEventListener("change", () => {
  loadDevicesForSelectedCompany(false);

  if (refreshIntervalId) clearInterval(refreshIntervalId);
  refreshIntervalId = setInterval(
    () => loadDevicesForSelectedCompany(),
    10000
  );

  // WebSocket room join
  const companyId = companySelect.value;
  if (socket && companyId) {
    socket.emit("join_company", { company_id: parseInt(companyId) });
    socket.emit("start_stream", {});
  }
});

searchInput.addEventListener("input", () => {
  renderDevices(currentDevices);
});

filterButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    filterButtons.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    currentFilter = btn.dataset.filter;
    renderDevices(currentDevices);
  });
});

modalCloseBtn.addEventListener("click", closeDeviceModal);
deviceModal.addEventListener("click", (e) => {
  if (e.target === deviceModal) closeDeviceModal();
});
window.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeDeviceModal();
});

// === Init ===
(async function init() {
  try {
    const companies = await fetchCompanies();
    renderCompanies(companies);
    emptyState.classList.remove("hidden");
    initSocket();
  } catch (err) {
    console.error("Init error:", err);
    errorState.classList.remove("hidden");
  }
})();
