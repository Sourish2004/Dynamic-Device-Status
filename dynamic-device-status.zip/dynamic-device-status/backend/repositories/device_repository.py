from db import get_db


def get_devices_for_company(company_id):
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT
                d.id,
                d.name,
                d.company_id,
                c.name AS company_name,
                MAX(dr.reading_time) AS last_reading_time
            FROM devices d
            JOIN companies c ON d.company_id = c.id
            LEFT JOIN device_readings dr ON dr.device_id = d.id
            WHERE d.company_id = %s
            GROUP BY d.id, d.name, d.company_id, c.name
            ORDER BY d.name;
            """,
            (company_id,),
        )
        return cur.fetchall()


def get_all_devices_with_company(conn=None):
    """
    Return all devices across all companies with company name.
    Used by live generator.
    """
    if conn is None:
        conn = get_db()

    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT
                d.id,
                d.name,
                d.company_id,
                c.name AS company_name
            FROM devices d
            JOIN companies c ON d.company_id = c.id
            ORDER BY c.name, d.name;
            """
        )
        return cur.fetchall()


def get_device_history(device_id, limit=50):
    """
    Return last N readings for a device (for charts).
    """
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT reading_time, value
            FROM device_readings
            WHERE device_id = %s
            ORDER BY reading_time DESC
            LIMIT %s;
            """,
            (device_id, limit),
        )
        return cur.fetchall()
