from db import get_db


def get_all_companies():
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT id, name
            FROM companies
            ORDER BY name;
            """
        )
        return cur.fetchall()
