# backend/app.py
from flask import Flask, send_from_directory
from flask_socketio import SocketIO, emit, join_room
from config import Config
from db import get_db, close_db
from api import register_blueprints
import random
from datetime import datetime, timezone
import threading

socketio = SocketIO(cors_allowed_origins="*")  # will init with app below
background_thread = None
thread_lock = threading.Lock()


def create_app():
    app = Flask(__name__, static_folder="../frontend", static_url_path="")
    app.config.from_object(Config)

    # Init SocketIO with app
    socketio.init_app(app)

    # DB lifecycle
    @app.before_request
    def before_request():
        get_db()

    @app.teardown_appcontext
    def teardown_db(exception=None):
        close_db(exception)

    # API blueprints
    register_blueprints(app)

    # Serve frontend
    @app.route("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    return app


app = create_app()


# -------- WebSocket events -------- #

@socketio.on("connect")
def handle_connect():
    print("Client connected")


@socketio.on("disconnect")
def handle_disconnect():
    print("Client disconnected")


@socketio.on("join_company")
def handle_join_company(data):
    """
    Frontend sends: { company_id: <int> }
    We put the client into a room 'company_<id>'
    """
    company_id = data.get("company_id")
    if not company_id:
        return
    room = f"company_{company_id}"
    join_room(room)
    print(f"Client joined room {room}")


# -------- Background live data simulator -------- #

def generate_live_readings():
    """
    Runs in the background:
    - Picks random devices
    - Inserts new readings
    - Emits 'device_reading' event to the relevant company room
    """
    from repositories.device_repository import get_all_devices_with_company
    from services.status_service import compute_device_status

    while True:
        socketio.sleep(5)  # every 5 seconds

        with app.app_context():
            conn = get_db()
            with conn.cursor() as cur:
                # Load a bunch of devices across companies
                devices = get_all_devices_with_company(conn)

                if not devices:
                    continue

                # Choose a random device to update
                device = random.choice(devices)
                device_id = device["id"]
                company_id = device["company_id"]
                company_name = device["company_name"]

                # Simulate a sensor value (for demo)
                value = round(random.uniform(10, 100), 2)

                # Insert reading
                cur.execute(
                    """
                    INSERT INTO device_readings (device_id, reading_time, value)
                    VALUES (%s, NOW(), %s)
                    RETURNING reading_time;
                    """,
                    (device_id, value),
                )
                row = cur.fetchone()
                conn.commit()

                last_reading_time = row["reading_time"]
                status, last_seen_iso = compute_device_status(last_reading_time)

                payload = {
                    "device_id": device_id,
                    "device_name": device["name"],
                    "company_id": company_id,
                    "company_name": company_name,
                    "value": float(value),
                    "reading_time": last_seen_iso,
                    "status": status,
                }

                room = f"company_{company_id}"
                socketio.emit("device_reading", payload, room=room)


@socketio.on("start_stream")
def start_stream(data):
    """
    Optional event if you want frontend to explicitly start streaming.
    For now, we start the background thread once globally on first connect.
    """
    global background_thread
    with thread_lock:
        if background_thread is None:
            background_thread = socketio.start_background_task(generate_live_readings)


# Start background thread automatically on first client connect
@socketio.on("connect")
def on_connect():
    global background_thread
    with thread_lock:
        if background_thread is None:
            background_thread = socketio.start_background_task(generate_live_readings)
    print("Client connected and live generator ensured.")


if __name__ == "__main__":
    # Use socketio.run instead of app.run
    socketio.run(app, debug=Config.DEBUG, host="0.0.0.0", port=5000)
