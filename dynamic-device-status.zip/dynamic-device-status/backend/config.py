import os

class Config:
    DB_NAME = "device_db"          # your database name in pgAdmin
    DB_USER = "postgres"           # or whatever user you use
    DB_PASSWORD = "Qwerty@123"  # <-- put your real postgres password here
    DB_HOST = "localhost"
    DB_PORT = 5432

    DEBUG = True