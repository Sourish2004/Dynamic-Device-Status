DB_CONFIG = {
    "host": "localhost",
    "database": "device_db",
    "user": "postgres",          # change it if your username is different
    "password": "Qwerty@123"   # replace with your PostgreSQL password
}