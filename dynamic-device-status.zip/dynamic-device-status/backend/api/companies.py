from flask import Blueprint, jsonify
from repositories.company_repository import get_all_companies

companies_bp = Blueprint("companies", __name__, url_prefix="/api/companies")


@companies_bp.route("", methods=["GET"])
def list_companies():
    companies = get_all_companies()
    return jsonify(companies), 200