from flask import Blueprint, jsonify, request
from repositories.device_repository import (
    get_devices_for_company,
    get_device_history,
)
from services.status_service import compute_device_status

devices_bp = Blueprint("devices", __name__, url_prefix="/api/companies")


@devices_bp.route("/<int:company_id>/devices", methods=["GET"])
def list_devices_for_company(company_id):
    raw_devices = get_devices_for_company(company_id)
    devices = []

    for row in raw_devices:
        last_read = row["last_reading_time"]

        if last_read is None:
            # Device has no readings yet
            status = "offline"
            last_seen_iso = None
        else:
            status, last_seen_iso = compute_device_status(last_read)

        devices.append({
            "id": row["id"],
            "name": row["name"],
            "company_id": row["company_id"],
            "company_name": row["company_name"],
            "status": status,
            "last_seen": last_seen_iso,
            "last_value": row.get("last_value", None),
        })

    return jsonify(devices), 200



# New: history endpoint
@devices_bp.route("/device/<int:device_id>/history", methods=["GET"])
def device_history(device_id):
    limit = request.args.get("limit", default=50, type=int)
    rows = get_device_history(device_id, limit=limit)

    history = [
        {
            "reading_time": r["reading_time"].isoformat() if r["reading_time"] else None,
            "value": float(r["value"]) if r["value"] is not None else None,
        }
        for r in rows
    ]

    # Return in chronological order (oldest first) for Chart.js
    history = list(reversed(history))
    return jsonify(history), 200
