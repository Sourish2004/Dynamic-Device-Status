from .companies import companies_bp
from .devices import devices_bp


def register_blueprints(app):
    app.register_blueprint(companies_bp)
    app.register_blueprint(devices_bp)