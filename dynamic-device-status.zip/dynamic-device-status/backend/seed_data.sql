INSERT INTO companies (name) VALUES
('Acme Tech'),
('Nova Networks'),
('Zenith Systems');

-- Devices for Acme Tech (company_id = 1)
INSERT INTO devices (name, company_id) VALUES
('Gateway-01', 1),
('Sensor-Alpha', 1),
('Camera-Lobby', 1),
('Server-East', 1);

-- Devices for Nova Networks (company_id = 2)
INSERT INTO devices (name, company_id) VALUES
('Router-Core', 2),
('AP-MeetingRoom', 2),
('Firewall-Main', 2);

-- Devices for Zenith Systems (company_id = 3)
INSERT INTO devices (name, company_id) VALUES
('IoT-Hub-1', 3),
('Weather-Station', 3),
('CCTV-Entrance', 3);

-- Example readings (you can run these repeatedly to simulate "online")
INSERT INTO device_readings (device_id, reading_time) VALUES
(1, NOW() - INTERVAL '30 seconds'),
(2, NOW() - INTERVAL '3 minutes'),
(3, NOW() - INTERVAL '80 seconds'),
(4, NOW() - INTERVAL '10 minutes'),
(5, NOW() - INTERVAL '10 seconds'),
(6, NOW() - INTERVAL '130 seconds'),
(7, NOW() - INTERVAL '5 minutes'),
(8, NOW() - INTERVAL '20 seconds'),
(9, NOW() - INTERVAL '1 minute'),
(10, NOW() - INTERVAL '4 minutes');
