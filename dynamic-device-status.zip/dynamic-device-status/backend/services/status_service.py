from datetime import datetime, timezone

ONLINE_THRESHOLD_SECONDS = 120  # 2 minutes


def compute_device_status(last_reading_ts):
    """Return ('online'|'offline', last_seen_iso or None)."""
    if last_reading_ts is None:
        return "offline", None

    if isinstance(last_reading_ts, str):
        last_dt = datetime.fromisoformat(last_reading_ts)
    else:
        last_dt = last_reading_ts

    now = datetime.now(timezone.utc)
    delta = (now - last_dt).total_seconds()

    status = "online" if delta <= ONLINE_THRESHOLD_SECONDS else "offline"
    return status, last_dt.isoformat()
